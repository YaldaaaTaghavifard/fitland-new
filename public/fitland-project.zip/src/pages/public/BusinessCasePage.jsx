import { useState, useMemo } from "react";
import {
  Briefcase,
  Layers,
  TrendingUp,
  Users,
  Target,
  ShieldCheck,
  MapPin,
  Sparkles,
  Calculator,
  CheckCircle2,
  AlertTriangle,
  Play,
  RotateCcw,
  Plus,
  Trash2,
  GraduationCap,
} from "lucide-react";
import { useLanguage } from "../../context/LanguageContext";
import { dataService } from "../../services/dataService";
import ScenarioRunnerModal from "../../components/common/ScenarioRunnerModal";

export default function BusinessCasePage() {
  const { t, formatCurrency, formatNumber } = useLanguage();
  const [activeTab, setActiveTab] = useState("discovery"); // discovery, value, bmc, competitors, personas, marketing, economics, security, roadmap
  const [isScenarioModalOpen, setIsScenarioModalOpen] = useState(false);

  // Editable BMC state
  const [bmc, setBmc] = useState(() => dataService.getBMC());
  const [editingBlock, setEditingBlock] = useState(null);
  const [newItemText, setNewItemText] = useState("");

  // Interactive Economics Calculator State
  const [calcActiveUsers, setCalcActiveUsers] = useState(1200);
  const [calcMonthlySubPrice, setCalcMonthlySubPrice] = useState(1200000);
  const [calcChurnRate, setCalcChurnRate] = useState(4.0); // %
  const [calcCac, setCalcCac] = useState(450000); // TOMAN

  // Calculate Unit Economics
  const economics = useMemo(() => {
    // ARPU = Average revenue per active paying member per month
    const commissionRevenuePerUser = 25000 * 3; // 75,000 تومان کارمزد میانگین کلاس‌ها
    const arpu = calcMonthlySubPrice + commissionRevenuePerUser;

    const churnDecimal = Math.max(0.005, calcChurnRate / 100);
    const averageLifespanMonths = 1 / churnDecimal;
    const ltv = Math.round(arpu * averageLifespanMonths);
    const ltvCacRatio = (ltv / Math.max(1, calcCac)).toFixed(1);

    const monthlyGrossRevenue = Math.round(calcActiveUsers * arpu);
    const annualRunRate = monthlyGrossRevenue * 12;
    const paybackPeriodMonths = (calcCac / Math.max(1, arpu)).toFixed(1);

    return {
      arpu,
      averageLifespanMonths: averageLifespanMonths.toFixed(1),
      ltv,
      ltvCacRatio,
      monthlyGrossRevenue,
      annualRunRate,
      paybackPeriodMonths,
      healthyRatio: Number(ltvCacRatio) >= 3,
    };
  }, [calcActiveUsers, calcMonthlySubPrice, calcChurnRate, calcCac]);

  const handleAddBmcItem = (blockKey) => {
    if (!newItemText.trim()) return;
    const updated = {
      ...bmc,
      [blockKey]: [...(bmc[blockKey] || []), newItemText.trim()],
    };
    setBmc(updated);
    dataService.updateBMC(updated);
    setNewItemText("");
  };

  const handleRemoveBmcItem = (blockKey, index) => {
    const updated = {
      ...bmc,
      [blockKey]: bmc[blockKey].filter((_, i) => i !== index),
    };
    setBmc(updated);
    dataService.updateBMC(updated);
  };

  const handleResetBMC = () => {
    const defaultData = dataService.getBMC();
    setBmc(defaultData);
    dataService.updateBMC(defaultData);
  };

  return (
    <div className="business-case-page">
      {/* Top Academic Banner */}
      <section className="academic-hero-header">
        <div className="container">
          <div className="academic-badge-strip">
            <span className="academic-tag">
              <Briefcase size={14} />
              <span>{t("academicHeader")}</span>
            </span>
            <span className="academic-divider">•</span>
            <span className="academic-student">
              <GraduationCap size={15} />
              <span>{t("academicAuthor")}</span>
            </span>
          </div>

          <h1 className="academic-title">{t("businessCaseTitle")}</h1>
          <p className="academic-subtitle">{t("businessCaseSubtitle")}</p>

          <div className="academic-cta-row">
            <button
              type="button"
              className="chic-btn chic-btn-primary"
              onClick={() => setIsScenarioModalOpen(true)}
            >
              <Play size={16} />
              <span>اجرای زنده ۱۰+ سناریوی ارزیابی (Live Scenarios)</span>
            </button>
            <a href="#bmc-section" className="chic-btn chic-btn-ghost">
              <Layers size={16} />
              <span>مشاهده و ویرایش بوم مدل کسب‌وکار (BMC)</span>
            </a>
          </div>
        </div>
      </section>

      {/* Navigation Tabs */}
      <nav className="case-tabs-nav-bar" aria-label="بخش‌های پرونده کسب‌وکار">
        <div className="container">
          <div className="tabs-scroll-wrapper">
            {[
              { id: "discovery", num: "۱", label: "کشف مسئله و بلوغ", icon: Target },
              { id: "value", num: "۲", label: "ارزش‌آفرینی چندجانبه", icon: Sparkles },
              { id: "bmc", num: "۳", label: "بوم مدل کسب‌وکار (BMC)", icon: Layers },
              { id: "competitors", num: "۴", label: "تحلیل رقبا و تمایز", icon: TrendingUp },
              { id: "personas", num: "۵", label: "پرسونا و سفر مشتری", icon: Users },
              { id: "marketing", num: "۶", label: "بازاریابی و قیف AIDA", icon: Briefcase },
              { id: "economics", num: "۷", label: "مدل درآمد و ماشین‌حساب", icon: Calculator },
              { id: "security", num: "۸", label: "امنیت و حریم خصوصی", icon: ShieldCheck },
              { id: "roadmap", num: "۹", label: "نقشه راه توسعه (Roadmap)", icon: MapPin },
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  type="button"
                  className={`case-tab-btn ${activeTab === tab.id ? "active" : ""}`}
                  onClick={() => setActiveTab(tab.id)}
                >
                  <span className="tab-num">{tab.num}</span>
                  <Icon size={15} className="tab-icon" />
                  <span className="tab-text">{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      <div className="container case-content-container">
        {/* =======================================================
            TAB 1: PROBLEM DISCOVERY & IDEA MATURITY
        ======================================================= */}
        {activeTab === "discovery" && (
          <div className="case-tab-content">
            <div className="case-section-intro">
              <span className="case-eyebrow">بخش اول</span>
              <h2>کشف مسئله، اصطکاک‌های بازار و اعتبارسنجی بلوغ ایده</h2>
              <p>
                تحلیل سیستماتیک چالش‌های واقعی ورزشکاران، مربیان و سالن‌های ورزشی بر مبنای متدولوژی اعتبارسنجی ایده و هشت پرسش بنیادین کارآفرینی.
              </p>
            </div>

            <div className="case-cards-grid">
              <div className="case-card">
                <h3>صورت‌بندی دقیق مسئله (Problem Formulation)</h3>
                <p>
                  در اکوسیستم کنونی باشگاه‌های ایران، زنجیره تعامل بین «ورزشکار»، «مربی» و «مدیریت باشگاه» دچار گسستگی شدید اطلاعاتی است:
                </p>
                <ul className="bullet-list">
                  <li>
                    <strong>عدم پیوستگی برنامه‌ها:</strong> برنامه‌های تمرینی و غذایی اغلب روی کاغذ یا پیام‌رسان‌های پراکنده (تلگرام/واتساپ) ارسال می‌شوند و پس از مدتی گم شده یا فراموش می‌گردند.
                  </li>
                  <li>
                    <strong>فقدان پایش کمّی:</strong> ورزشکاران قادر به مشاهده روند تغییرات وزن، ابعاد عضلانی و درصد چربی خود به صورت نمودارهای پیوسته نیستند.
                  </li>
                  <li>
                    <strong>اصطکاک نقدینگی و مالی:</strong> هزینه‌های بالای اشتراک‌های سالانه مانع ورود ورزشکاران می‌شود و سیستم پرداخت اقساطی بدون کارمزد یا شفاف وجود ندارد.
                  </li>
                  <li>
                    <strong>تداخل‌های زمانی در رزرو:</strong> هماهنگی جلسات خصوصی مربی با تلفن و چت دستی انجام شده و منجر به هم‌پوشانی و نارضایتی می‌گردد.
                  </li>
                </ul>
              </div>

              <div className="case-card">
                <h3>تفکیک فرضیه‌ها از شواهد واقعی (Hypothesis vs Evidence)</h3>
                <div className="table-responsive">
                  <table className="case-table">
                    <thead>
                      <tr>
                        <th>موضوع</th>
                        <th>فرضیه اولیه (Hypothesis)</th>
                        <th>شواهد میدانی و ارزیابی (Evidence)</th>
                        <th>وضعیت</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>پرداخت اقساطی</td>
                        <td>کاربران از پلن اقساطی برای خرید اشتراک باشگاه استقبال می‌کنند.</td>
                        <td>طبق آمار صنعت فین‌تک، سرویس‌های BNPL نرخ تبدیل سبد خرید را بین ۲۰ تا ۳۰ درصد افزایش می‌دهند.</td>
                        <td><span className="status-badge success">اثبات‌شده</span></td>
                      </tr>
                      <tr>
                        <td>نیاز مربیان</td>
                        <td>مربیان وقت کافی برای ثبت آنلاین برنامه‌ها دارند.</td>
                        <td>مربیان نیاز به ابزار سریع (کمتر از ۳ دقیقه) دارند، وگرنه به کاغذ برمی‌گردند (رابط کاربری باید فوق‌سریع باشد).</td>
                        <td><span className="status-badge warning">مشروط به سادگی UI</span></td>
                      </tr>
                      <tr>
                        <td>رزرو همزمان</td>
                        <td>سیستم رزرو آنلاین مانع تداخل جلسات می‌شود.</td>
                        <td>با الگوریتم Collision Prevention در سطح کلاینت/سرور، خطای رزرو تکراری به صفر می‌رسد.</td>
                        <td><span className="status-badge success">پیاده‌سازی‌شده در فیت‌لند</span></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            {/* 8 Golden Course Questions Evaluation */}
            <div className="case-card full-width mt-6">
              <h3>ارزیابی اعتبار ایده با هشت پرسش طلایی درس کارآفرینی</h3>
              <div className="golden-questions-grid">
                {[
                  { q: "۱. آیا مسئله واقعی و دردناک است؟", a: "بله، ریزش اعضای باشگاه به دلیل عدم مشاهده پیشرفت و نبود برنامه مدون به بیش از ۴۵٪ در ماه سوم می‌رسد." },
                  { q: "۲. مشتری حاضر به پرداخت پول برای حل آن است؟", a: "بله، ورزشکاران در حال حاضر مبالغ بالایی بابت مربی خصوصی و مکمل پرداخت می‌کنند؛ شفاف‌سازی این فرایند ارزش خرید دارد." },
                  { q: "۳. آیا بازار به اندازه کافی بزرگ و در حال رشد است؟", a: "بازار سلامت و تناسب اندام شهری ایران با بیش از ۲۰ هزار باشگاه فعال و گرایش شدید نسل Z به تندرستی در حال توسعه است." },
                  { q: "۴. آیا راهکار ما مزیت رقابتی پایدار (Unfair Advantage) دارد؟", a: "بله، یکپارچگی سه‌گانه ورزشکار + مربی + مدیریت به همراه مدل پرداخت اقساطی و پرونده تحلیلی بدن." },
                  { q: "۵. کانال‌های دستیابی به مشتری مقیاس‌پذیر هستند؟", a: "بله، مدل B2B2C از طریق ورود مستقیم باشگاه‌ها و مربیان، شاگردان آنان را با کمترین CAC به پلتفرم می‌آورد." },
                  { q: "۶. آیا مدل درآمدی تکرارشونده و شفاف است؟", a: "بله، ترکیب اشتراک‌های دوره‌ای (MRR)، کارمزد تراکنش کلاس‌ها و فروش تجهیزات." },
                  { q: "۷. موانع ورود رقبا و قابلیت دفاع چیست؟", a: "اثر شبکه‌ای مربی-شاگرد و دیتای انباشته‌شده اندازه‌گیری‌های چندساله کاربر که هزینه تعویض (Switching Cost) ایجاد می‌کند." },
                  { q: "۸. قابلیت اجرای تیم و تناسب راه‌حل چیست؟", a: "طراحی ماژولار React 19 با تایپوگرافی دوزبانه استاندارد، دسترسی مبتنی بر نقش و ذخیره‌سازی داده‌های ساخت‌یافته." },
                ].map((item, i) => (
                  <div className="question-box" key={i}>
                    <strong>{item.q}</strong>
                    <p>{item.a}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* =======================================================
            TAB 2: VALUE CREATION
        ======================================================= */}
        {activeTab === "value" && (
          <div className="case-tab-content">
            <div className="case-section-intro">
              <span className="case-eyebrow">بخش دوم</span>
              <h2>ارزش‌آفرینی چندجانبه برای ذی‌نفعان اکوسیستم</h2>
              <p>
                تفکیک دقیق ارزش‌های کاربردی، اقتصادی، مبادله‌ای و استراتژیک برای هر یک از بازیگران پلتفرم فیت‌لند.
              </p>
            </div>

            <div className="value-stakeholders-grid">
              <div className="stakeholder-card">
                <div className="card-top-icon bg-orange">
                  <Users size={22} />
                </div>
                <h3>ارزش برای ورزشکار (Member)</h3>
                <ul className="value-list">
                  <li><strong>ارزش کاربردی:</strong> مشاهده شفاف برنامه حرکات، فیلم تمرین، جدول وعده‌های غذایی و نمودار لاغری/حجم.</li>
                  <li><strong>ارزش اقتصادی:</strong> امکان پرداخت اقساطی شهریه بدون فشار نقدی و بهره، تخفیف در خرید مکمل و وسایل ورزشی.</li>
                  <li><strong>ارزش روانی و انگیزشی:</strong> عضویت در جامعه سالم، دریافت نشان‌های پیشرفت و احساس تعهد به برنامه.</li>
                </ul>
              </div>

              <div className="stakeholder-card">
                <div className="card-top-icon bg-green">
                  <Briefcase size={22} />
                </div>
                <h3>ارزش برای مربی (Trainer)</h3>
                <ul className="value-list">
                  <li><strong>ارزش کاربردی:</strong> طراحی برنامه در کمتر از ۳ دقیقه با قالب‌های آماده و دسته‌بندی عضلانی استاندارد.</li>
                  <li><strong>ارزش اقتصادی:</strong> دریافت درآمد مستقیم از شاگردان بدون دغدغه پیگیری کارت‌به‌کارت و حسابداری.</li>
                  <li><strong>ارزش استراتژیک:</strong> برندسازی شخصی، سیستم امتیازدهی شفاف، انتخاب مربی برتر ماه و جذب شاگردان جدید.</li>
                </ul>
              </div>

              <div className="stakeholder-card">
                <div className="card-top-icon bg-blue">
                  <ShieldCheck size={22} />
                </div>
                <h3>ارزش برای باشگاه و مدیر (Gym Admin)</h3>
                <ul className="value-list">
                  <li><strong>ارزش مبادله‌ای:</strong> گزارش‌های مالی تجمیعی، رصد لحظه‌ای رزروها و ظرفیت باقیمانده سالن.</li>
                  <li><strong>ارزش اقتصادی:</strong> کاهش نرخ ریزش اعضا (Churn Rate) و افزایش جریان نقدی ماهانه قابل پیش‌بینی.</li>
                  <li><strong>ارزش حاکمیتی:</strong> مدیریت نقش‌ها، جلوگیری از تداخل سانس‌ها و انبارداری دقیق محصولات فیزیکی.</li>
                </ul>
              </div>
            </div>
          </div>
        )}

        {/* =======================================================
            TAB 3: INTERACTIVE BUSINESS MODEL CANVAS (BMC)
        ======================================================= */}
        {activeTab === "bmc" && (
          <div className="case-tab-content" id="bmc-section">
            <div className="case-section-intro">
              <div className="flex-between">
                <div>
                  <span className="case-eyebrow">بخش سوم</span>
                  <h2>بوم تعاملی مدل کسب‌وکار (Interactive Business Model Canvas)</h2>
                  <p>
                    بوم ۹ بخشی تعاملی؛ مدیر پروژه و داور محترم می‌توانند آیتم‌ها را ویرایش، حذف یا موارد جدید اضافه نمایند. تغییرات در دیتابیس لوکال پایدار می‌ماند.
                  </p>
                </div>
                <button
                  type="button"
                  className="chic-btn chic-btn-ghost btn-sm"
                  onClick={handleResetBMC}
                >
                  <RotateCcw size={14} />
                  <span>بازنشانی بوم اولیه</span>
                </button>
              </div>
            </div>

            <div className="bmc-grid">
              {/* 1. Key Partners */}
              <div className="bmc-block bmc-partners">
                <div className="bmc-block-head">
                  <h4>شرکای کلیدی (Key Partnerships)</h4>
                  <button
                    type="button"
                    className="bmc-add-btn"
                    onClick={() => setEditingBlock(editingBlock === "keyPartnerships" ? null : "keyPartnerships")}
                  >
                    <Plus size={14} />
                  </button>
                </div>
                <ul className="bmc-items">
                  {bmc.keyPartnerships?.map((item, idx) => (
                    <li key={idx}>
                      <span>{item}</span>
                      <button type="button" onClick={() => handleRemoveBmcItem("keyPartnerships", idx)}>
                        <Trash2 size={12} />
                      </button>
                    </li>
                  ))}
                </ul>
                {editingBlock === "keyPartnerships" && (
                  <div className="bmc-add-input">
                    <input
                      type="text"
                      placeholder="عنوان شریک جدید..."
                      value={newItemText}
                      onChange={(e) => setNewItemText(e.target.value)}
                    />
                    <button type="button" onClick={() => handleAddBmcItem("keyPartnerships")}>
                      افزودن
                    </button>
                  </div>
                )}
              </div>

              {/* Middle Top: Key Activities & Resources */}
              <div className="bmc-block-column">
                <div className="bmc-block">
                  <div className="bmc-block-head">
                    <h4>فعالیت‌های کلیدی (Key Activities)</h4>
                    <button
                      type="button"
                      className="bmc-add-btn"
                      onClick={() => setEditingBlock(editingBlock === "keyActivities" ? null : "keyActivities")}
                    >
                      <Plus size={14} />
                    </button>
                  </div>
                  <ul className="bmc-items">
                    {bmc.keyActivities?.map((item, idx) => (
                      <li key={idx}>
                        <span>{item}</span>
                        <button type="button" onClick={() => handleRemoveBmcItem("keyActivities", idx)}>
                          <Trash2 size={12} />
                        </button>
                      </li>
                    ))}
                  </ul>
                  {editingBlock === "keyActivities" && (
                    <div className="bmc-add-input">
                      <input
                        type="text"
                        placeholder="فعالیت جدید..."
                        value={newItemText}
                        onChange={(e) => setNewItemText(e.target.value)}
                      />
                      <button type="button" onClick={() => handleAddBmcItem("keyActivities")}>
                        افزودن
                      </button>
                    </div>
                  )}
                </div>

                <div className="bmc-block">
                  <div className="bmc-block-head">
                    <h4>منابع کلیدی (Key Resources)</h4>
                    <button
                      type="button"
                      className="bmc-add-btn"
                      onClick={() => setEditingBlock(editingBlock === "keyResources" ? null : "keyResources")}
                    >
                      <Plus size={14} />
                    </button>
                  </div>
                  <ul className="bmc-items">
                    {bmc.keyResources?.map((item, idx) => (
                      <li key={idx}>
                        <span>{item}</span>
                        <button type="button" onClick={() => handleRemoveBmcItem("keyResources", idx)}>
                          <Trash2 size={12} />
                        </button>
                      </li>
                    ))}
                  </ul>
                  {editingBlock === "keyResources" && (
                    <div className="bmc-add-input">
                      <input
                        type="text"
                        placeholder="منبع جدید..."
                        value={newItemText}
                        onChange={(e) => setNewItemText(e.target.value)}
                      />
                      <button type="button" onClick={() => handleAddBmcItem("keyResources")}>
                        افزودن
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Value Proposition */}
              <div className="bmc-block bmc-value-prop">
                <div className="bmc-block-head">
                  <h4>ارزش‌های پیشنهادی (Value Propositions)</h4>
                  <button
                    type="button"
                    className="bmc-add-btn"
                    onClick={() => setEditingBlock(editingBlock === "valuePropositions" ? null : "valuePropositions")}
                  >
                    <Plus size={14} />
                  </button>
                </div>
                <ul className="bmc-items">
                  {bmc.valuePropositions?.map((item, idx) => (
                    <li key={idx}>
                      <span>{item}</span>
                      <button type="button" onClick={() => handleRemoveBmcItem("valuePropositions", idx)}>
                        <Trash2 size={12} />
                      </button>
                    </li>
                  ))}
                </ul>
                {editingBlock === "valuePropositions" && (
                  <div className="bmc-add-input">
                    <input
                      type="text"
                      placeholder="ارزش پیشنهادی جدید..."
                      value={newItemText}
                      onChange={(e) => setNewItemText(e.target.value)}
                    />
                    <button type="button" onClick={() => handleAddBmcItem("valuePropositions")}>
                      افزودن
                    </button>
                  </div>
                )}
              </div>

              {/* Middle Right: Relationships & Channels */}
              <div className="bmc-block-column">
                <div className="bmc-block">
                  <div className="bmc-block-head">
                    <h4>ارتباط با مشتریان (Customer Relationships)</h4>
                    <button
                      type="button"
                      className="bmc-add-btn"
                      onClick={() => setEditingBlock(editingBlock === "customerRelationships" ? null : "customerRelationships")}
                    >
                      <Plus size={14} />
                    </button>
                  </div>
                  <ul className="bmc-items">
                    {bmc.customerRelationships?.map((item, idx) => (
                      <li key={idx}>
                        <span>{item}</span>
                        <button type="button" onClick={() => handleRemoveBmcItem("customerRelationships", idx)}>
                          <Trash2 size={12} />
                        </button>
                      </li>
                    ))}
                  </ul>
                  {editingBlock === "customerRelationships" && (
                    <div className="bmc-add-input">
                      <input
                        type="text"
                        placeholder="نحوه ارتباط جدید..."
                        value={newItemText}
                        onChange={(e) => setNewItemText(e.target.value)}
                      />
                      <button type="button" onClick={() => handleAddBmcItem("customerRelationships")}>
                        افزودن
                      </button>
                    </div>
                  )}
                </div>

                <div className="bmc-block">
                  <div className="bmc-block-head">
                    <h4>کانال‌های توزیع (Channels)</h4>
                    <button
                      type="button"
                      className="bmc-add-btn"
                      onClick={() => setEditingBlock(editingBlock === "channels" ? null : "channels")}
                    >
                      <Plus size={14} />
                    </button>
                  </div>
                  <ul className="bmc-items">
                    {bmc.channels?.map((item, idx) => (
                      <li key={idx}>
                        <span>{item}</span>
                        <button type="button" onClick={() => handleRemoveBmcItem("channels", idx)}>
                          <Trash2 size={12} />
                        </button>
                      </li>
                    ))}
                  </ul>
                  {editingBlock === "channels" && (
                    <div className="bmc-add-input">
                      <input
                        type="text"
                        placeholder="کانال جدید..."
                        value={newItemText}
                        onChange={(e) => setNewItemText(e.target.value)}
                      />
                      <button type="button" onClick={() => handleAddBmcItem("channels")}>
                        افزودن
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Customer Segments */}
              <div className="bmc-block bmc-segments">
                <div className="bmc-block-head">
                  <h4>بخش‌های مشتریان (Customer Segments)</h4>
                  <button
                    type="button"
                    className="bmc-add-btn"
                    onClick={() => setEditingBlock(editingBlock === "customerSegments" ? null : "customerSegments")}
                  >
                    <Plus size={14} />
                  </button>
                </div>
                <ul className="bmc-items">
                  {bmc.customerSegments?.map((item, idx) => (
                    <li key={idx}>
                      <span>{item}</span>
                      <button type="button" onClick={() => handleRemoveBmcItem("customerSegments", idx)}>
                        <Trash2 size={12} />
                      </button>
                    </li>
                  ))}
                </ul>
                {editingBlock === "customerSegments" && (
                  <div className="bmc-add-input">
                    <input
                      type="text"
                      placeholder="بخش مشتری جدید..."
                      value={newItemText}
                      onChange={(e) => setNewItemText(e.target.value)}
                    />
                    <button type="button" onClick={() => handleAddBmcItem("customerSegments")}>
                      افزودن
                    </button>
                  </div>
                )}
              </div>

              {/* Bottom: Cost Structure & Revenue Streams */}
              <div className="bmc-bottom-row">
                <div className="bmc-block">
                  <div className="bmc-block-head">
                    <h4>ساختار هزینه‌ها (Cost Structure)</h4>
                    <button
                      type="button"
                      className="bmc-add-btn"
                      onClick={() => setEditingBlock(editingBlock === "costStructure" ? null : "costStructure")}
                    >
                      <Plus size={14} />
                    </button>
                  </div>
                  <ul className="bmc-items">
                    {bmc.costStructure?.map((item, idx) => (
                      <li key={idx}>
                        <span>{item}</span>
                        <button type="button" onClick={() => handleRemoveBmcItem("costStructure", idx)}>
                          <Trash2 size={12} />
                        </button>
                      </li>
                    ))}
                  </ul>
                  {editingBlock === "costStructure" && (
                    <div className="bmc-add-input">
                      <input
                        type="text"
                        placeholder="هزینه جدید..."
                        value={newItemText}
                        onChange={(e) => setNewItemText(e.target.value)}
                      />
                      <button type="button" onClick={() => handleAddBmcItem("costStructure")}>
                        افزودن
                      </button>
                    </div>
                  )}
                </div>

                <div className="bmc-block">
                  <div className="bmc-block-head">
                    <h4>جریان‌های درآمدی (Revenue Streams)</h4>
                    <button
                      type="button"
                      className="bmc-add-btn"
                      onClick={() => setEditingBlock(editingBlock === "revenueStreams" ? null : "revenueStreams")}
                    >
                      <Plus size={14} />
                    </button>
                  </div>
                  <ul className="bmc-items">
                    {bmc.revenueStreams?.map((item, idx) => (
                      <li key={idx}>
                        <span>{item}</span>
                        <button type="button" onClick={() => handleRemoveBmcItem("revenueStreams", idx)}>
                          <Trash2 size={12} />
                        </button>
                      </li>
                    ))}
                  </ul>
                  {editingBlock === "revenueStreams" && (
                    <div className="bmc-add-input">
                      <input
                        type="text"
                        placeholder="جریان درآمد جدید..."
                        value={newItemText}
                        onChange={(e) => setNewItemText(e.target.value)}
                      />
                      <button type="button" onClick={() => handleAddBmcItem("revenueStreams")}>
                        افزودن
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* =======================================================
            TAB 4: COMPETITOR ANALYSIS & DIFFERENTIATION
        ======================================================= */}
        {activeTab === "competitors" && (
          <div className="case-tab-content">
            <div className="case-section-intro">
              <span className="case-eyebrow">بخش چهارم</span>
              <h2>تحلیل رقبا و ماتریس تمایز استراتژیک FitLand</h2>
              <p>
                بررسی بی‌طرفانه و مبتنی بر واقعیت ۳ بازیگر شاخص بازار سلامت ایران در مقایسه با فیت‌لند (بدون جعل آمار؛ پارامترهای نامشخص به عنوان «نیازمند تحقیق» درج شده‌اند).
              </p>
            </div>

            <div className="table-responsive">
              <table className="case-table full-width">
                <thead>
                  <tr>
                    <th>معیار مقایسه</th>
                    <th>فیت‌لند (FitLand)</th>
                    <th>فیتامین (Fitamin)</th>
                    <th>هوم‌فیت (HomeFit)</th>
                    <th>سیستم سنتی باشگاه‌ها</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td><strong>نوع راهکار</strong></td>
                    <td>پلتفرم یکپارچه وب/موبایل با ۳ نقش</td>
                    <td>اپلیکیشن تمرین در خانه و رژیم آنلاین</td>
                    <td>پکیج‌های ویدیویی ورزش در منزل</td>
                    <td>دفترچه کاغذی و چت‌های واتساپ/تلگرام</td>
                  </tr>
                  <tr>
                    <td><strong>پرداخت اقساطی (BNPL)</strong></td>
                    <td><span className="text-emerald-500 font-bold">دارد (بدون کارمزد در ۲ تا ۶ قسط)</span></td>
                    <td>صرفاً پرداخت یکجا برای پکیج‌ها</td>
                    <td>صرفاً خرید نقدی دوره‌ها</td>
                    <td>توافقی با منشی (غیرخودکار و پرریسک)</td>
                  </tr>
                  <tr>
                    <td><strong>جلوگیری از تداخل زمانی رزرو</strong></td>
                    <td><span className="text-emerald-500 font-bold">دارد (موتور ضدتداخل ساعت و مربی)</span></td>
                    <td>ندارد (تمرینات آفلاین غیرحضوری)</td>
                    <td>ندارد (ویدیوهای از پیش ضبط‌شده)</td>
                    <td>ندارد (تداخل بسیار شایع در سانس‌ها)</td>
                  </tr>
                  <tr>
                    <td><strong>داشبورد و نمودار پیشرفت</strong></td>
                    <td>نمودار زنده سنجه‌ها و آنالیز دوره‌ای</td>
                    <td>ثبت دستی در اپلیکیشن</td>
                    <td>بسیار محدود یا فاقد نمودار</td>
                    <td>موجود نیست</td>
                  </tr>
                  <tr>
                    <td><strong>فروشگاه متصل به برنامه</strong></td>
                    <td>دارد (پیشنهاد تجهیزات بر اساس برنامه)</td>
                    <td>موجود نیست</td>
                    <td>فروش کش و مت متفرقه</td>
                    <td>بوفه فیزیکی باشگاه</td>
                  </tr>
                  <tr>
                    <td><strong>سهم بازار و داده‌های مالی</strong></td>
                    <td>پروژه دانشگاهی و در فاز اعتبارسنجی</td>
                    <td><span className="badge-research">نیازمند تحقیق دقیق</span></td>
                    <td><span className="badge-research">نیازمند تحقیق دقیق</span></td>
                    <td>پراکنده و غیرمتمرکز</td>
                  </tr>
                  <tr>
                    <td><strong>نقاط ضعف رقیب</strong></td>
                    <td>—</td>
                    <td>تعامل ضعیف مربی انسانی، تمرکز زیاد بر ربات</td>
                    <td>عدم انعطاف برنامه با شرایط واقعی فرد</td>
                    <td>عدم پایداری اطلاعات و احتمال گم شدن کاغذها</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* =======================================================
            TAB 5: PERSONAS & CUSTOMER JOURNEY
        ======================================================= */}
        {activeTab === "personas" && (
          <div className="case-tab-content">
            <div className="case-section-intro">
              <span className="case-eyebrow">بخش پنجم</span>
              <h2>پرسوناها و نقشه جامع سفر مشتری (Customer Journey Map)</h2>
              <p>
                مدل‌سازی روان‌شناختی و رفتاری دو بازیگر اصلی (ورزشکار عضو و مربی تخصصی) به همراه ۵ گام سفر کاربر از آگاهی تا تمدید.
              </p>
            </div>

            <div className="personas-grid">
              {/* Persona 1: Member */}
              <div className="persona-card">
                <div className="persona-header">
                  <div className="persona-avatar bg-orange">ع</div>
                  <div>
                    <h3>علی رضایی (ورزشکار هدف)</h3>
                    <span>مهندس نرم‌افزار، ۲۶ ساله، یزد</span>
                  </div>
                </div>
                <div className="persona-body">
                  <div className="persona-section">
                    <strong>اهداف و انگیزه‌ها:</strong>
                    <p>کاهش ۸ کیلوگرم چربی شکمی، اصلاح قوز پشت ناشی از کار پشت کامپیوتر، افزایش انرژی روزانه.</p>
                  </div>
                  <div className="persona-section">
                    <strong>مشکلات و ناکامی‌ها (Pain Points):</strong>
                    <p>فراموش کردن حرکات تمرینی، بی‌نظمی در ثبت وزن، بالا بودن شهریه سالانه به صورت یکجا.</p>
                  </div>
                  <div className="persona-section">
                    <strong>رفتار دیجیتال:</strong>
                    <p>روزانه بیش از ۴ ساعت آنلاین، ترجیح وب‌سایت‌های سریع بدون اتلاف وقت، استفاده از ابزارهای آنلاین محاسبه BMI.</p>
                  </div>
                </div>
              </div>

              {/* Persona 2: Trainer */}
              <div className="persona-card">
                <div className="persona-header">
                  <div className="persona-avatar bg-blue">س</div>
                  <div>
                    <h3>سارا محمدی (مربی تخصصی)</h3>
                    <span>مربی رسمی فیتنس، ۳۱ ساله، تهران</span>
                  </div>
                </div>
                <div className="persona-body">
                  <div className="persona-section">
                    <strong>اهداف و انگیزه‌ها:</strong>
                    <p>مدیریت همزمان ۳۰ شاگرد بدون خطای تداخل سانس، افزایش درآمد از طریق کلاس‌های گروهی و شناخته شدن به عنوان مربی برتر.</p>
                  </div>
                  <div className="persona-section">
                    <strong>مشکلات و ناکامی‌ها (Pain Points):</strong>
                    <p>ارسال پیام‌های تکراری در تلگرام، فراموشی اعضا در پرداخت به موقع شهریه، عدم دسترسی به تاریخچه تمرین شاگرد.</p>
                  </div>
                  <div className="persona-section">
                    <strong>رفتار دیجیتال:</strong>
                    <p>فعال در اینستاگرام با ۱۲ هزار دنبال‌کننده، نیازمند پنلی که روی تبلت و موبایل سریع باز شود.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* 5-Step Customer Journey Map */}
            <div className="case-card full-width mt-6">
              <h3>نقشه سفر مشتری ۵ مرحله‌ای (Customer Journey Map)</h3>
              <div className="journey-steps-grid">
                {[
                  {
                    step: "۱. آگاهی (Awareness)",
                    action: "مشاهده پست اینستاگرام یا محاسبه رایگان BMI در سایت",
                    feeling: "کنجکاوی و احساس نیاز به تغییر",
                    touchpoint: "لندینگ پیج، ماشین‌حساب آنلاین، شبکه‌های اجتماعی",
                  },
                  {
                    step: "۲. بررسی (Consideration)",
                    action: "مقایسه پلن‌های عضویت، خواندن رزومه مربیان و دیدن داستان‌های موفقیت",
                    feeling: "سنجش ارزش در برابر هزینه و اطمینان از تخصص مربیان",
                    touchpoint: "صفحه /plans، صفحه /trainers، نظرات اعضا",
                  },
                  {
                    step: "۳. خرید (Purchase)",
                    action: "انتخاب پلن طلایی، انتخاب مدل اقساطی و پرداخت پیش‌پرداخت",
                    feeling: "رضایت از عدم پرداخت یکجای مبلغ بالا و سهولت فرایند",
                    touchpoint: "درگاه پرداخت آزمایشی اقساطی، پیامک/نوتیفیکیشن تایید",
                  },
                  {
                    step: "۴. استفاده (Usage)",
                    action: "دریافت برنامه از مربی، ثبت جلسات در تقویم و ثبت هفتگی وزن",
                    feeling: "انگیزه بالا و احساس همراهی مربی در طول هفته",
                    touchpoint: "داشبورد عضو، جدول تمرین، نمودار تغییرات وزن",
                  },
                  {
                    step: "۵. تمدید و وفاداری (Retention)",
                    action: "مشاهده کاهش وزن روی نمودار، پرداخت قسط بعدی و تمدید اشتراک",
                    feeling: "دستیابی به نتیجه ملموس و معرفی پلتفرم به دوستان",
                    touchpoint: "گزارش تحلیلی ماهانه، دریافت نشان عضو متعهد",
                  },
                ].map((item, idx) => (
                  <div className="journey-box" key={idx}>
                    <span className="step-num">{item.step}</span>
                    <div className="journey-detail">
                      <small>اقدام کاربر:</small>
                      <strong>{item.action}</strong>
                    </div>
                    <div className="journey-detail">
                      <small>احساس و نگرش:</small>
                      <p>{item.feeling}</p>
                    </div>
                    <div className="journey-detail">
                      <small>نقاط تماس (Touchpoints):</small>
                      <span>{item.touchpoint}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* =======================================================
            TAB 6: DIGITAL MARKETING & AIDA
        ======================================================= */}
        {activeTab === "marketing" && (
          <div className="case-tab-content">
            <div className="case-section-intro">
              <span className="case-eyebrow">بخش ششم</span>
              <h2>استراتژی بازاریابی دیجیتال و قیف فروش AIDA</h2>
              <p>
                برنامه‌ریزی جذب، تبدیل، فعال‌سازی و نگه‌داشت کاربران از طریق آمیخته بازاریابی درون‌گرا (Inbound) و همکاری با باشگاه‌های فیزیکی.
              </p>
            </div>

            <div className="aida-funnel-grid">
              <div className="aida-step aida-attention">
                <div className="aida-head">
                  <span className="aida-letter">A</span>
                  <div>
                    <h4>جلب توجه (Attention)</h4>
                    <small>ایجاد آگاهی اولیه در مخاطب هدف</small>
                  </div>
                </div>
                <ul className="bullet-list">
                  <li>سئو ارگانیک برای عبارات پرتکرار: «محاسبه BMI»، «برنامه بدنسازی آنلاین»، «رژیم عضله‌سازی».</li>
                  <li>ویدیوهای کوتاه اصلاح حرکات تمرینی در ریلز اینستاگرام توسط مربیان رسمی فیت‌لند.</li>
                  <li>بنرهای همکاری مشترک در ورودی باشگاه‌های فیزیکی منتخب.</li>
                </ul>
              </div>

              <div className="aida-step aida-interest">
                <div className="aida-head">
                  <span className="aida-letter">I</span>
                  <div>
                    <h4>ایجاد علاقه (Interest)</h4>
                    <small>نمایش تفاوت رویکرد فیت‌لند با روش‌های سنتی</small>
                  </div>
                </div>
                <ul className="bullet-list">
                  <li>ماشین‌حساب تعاملی آنلاین که کالری روزانه و شاخص توده بدنی را در ۳ ثانیه نشان می‌دهد.</li>
                  <li>داستان‌های واقعی همراه با اعداد ملموس (مثلاً کاهش ۱۲ کیلوگرم در ۴ ماه با نمودار اثبات‌شده).</li>
                  <li>امکان مشاهده رزومه، ویدیو و مدارک مربیان قبل از ثبت‌نام.</li>
                </ul>
              </div>

              <div className="aida-step aida-desire">
                <div className="aida-head">
                  <span className="aida-letter">D</span>
                  <div>
                    <h4>ایجاد تمایل و قصد خرید (Desire)</h4>
                    <small>حذف موانع تصمیم‌گیری و ترس از ضرر</small>
                  </div>
                </div>
                <ul className="bullet-list">
                  <li>امکان پرداخت اقساطی بدون بهره برای از بین بردن تردید مالی در لحظه ثبت‌نام.</li>
                  <li>تضمین عدم تداخل سانس‌ها و پاسخگویی مربی در کمتر از ۲۴ ساعت.</li>
                  <li>ارائه ۳ روز آزمایش رایگان یا ضمانت بازگشت وجه در صورت عدم رضایت.</li>
                </ul>
              </div>

              <div className="aida-step aida-action">
                <div className="aida-head">
                  <span className="aida-letter">A</span>
                  <div>
                    <h4>اقدام به خرید و عضویت (Action)</h4>
                    <small>فرایند ثبت‌نام فوق‌سریع و روان</small>
                  </div>
                </div>
                <ul className="bullet-list">
                  <li>فرم ثبت‌نام تک‌مرحله‌ای با فقط ۳ فیلد (نام، ایمیل، رمز).</li>
                  <li>درگاه پرداخت آسان همراه با فاکتور رسمی و جدول شفاف اقساط.</li>
                  <li>آنبردینگ فوری و هدایت مستقیم به ثبت اولین سنجه و انتخاب مربی.</li>
                </ul>
              </div>
            </div>
          </div>
        )}

        {/* =======================================================
            TAB 7: REVENUE MODEL & UNIT ECONOMICS CALCULATOR
        ======================================================= */}
        {activeTab === "economics" && (
          <div className="case-tab-content">
            <div className="case-section-intro">
              <span className="case-eyebrow">بخش هفتم</span>
              <h2>مدل درآمدی و ماشین‌حساب پویای سنجه‌های اقتصادی (Unit Economics)</h2>
              <p>
                محاسبه زنده شاخص‌های CAC, LTV, Churn, ARPU و نسبت سلامت رشد کسب‌وکار بر مبنای فرضیات قابل تنظیم.
              </p>
            </div>

            <div className="economics-wrapper-grid">
              {/* Controls Column */}
              <div className="economics-controls-card">
                <h3>متغیرهای ورودی مدل مالی (Assumptions)</h3>
                <p className="note-text">
                  با تغییر اسلایدرهای زیر، شاخص‌های LTV، درآمد تکرارشونده و دوره بازگشت سرمایه در لحظه بازتعریف می‌شوند:
                </p>

                <div className="econ-slider-group">
                  <div className="slider-label-row">
                    <span>تعداد کاربران فعال پلتفرم:</span>
                    <strong>{formatNumber(calcActiveUsers)} نفر</strong>
                  </div>
                  <input
                    type="range"
                    min="100"
                    max="10000"
                    step="100"
                    value={calcActiveUsers}
                    onChange={(e) => setCalcActiveUsers(Number(e.target.value))}
                    className="calc-range-input"
                  />
                </div>

                <div className="econ-slider-group">
                  <div className="slider-label-row">
                    <span>میانگین شهریه ماهانه اشتراک:</span>
                    <strong>{formatCurrency(calcMonthlySubPrice)}</strong>
                  </div>
                  <input
                    type="range"
                    min="500000"
                    max="3000000"
                    step="50000"
                    value={calcMonthlySubPrice}
                    onChange={(e) => setCalcMonthlySubPrice(Number(e.target.value))}
                    className="calc-range-input"
                  />
                </div>

                <div className="econ-slider-group">
                  <div className="slider-label-row">
                    <span>نرخ ریزش ماهانه (Monthly Churn Rate):</span>
                    <strong>{calcChurnRate}٪</strong>
                  </div>
                  <input
                    type="range"
                    min="1.0"
                    max="15.0"
                    step="0.5"
                    value={calcChurnRate}
                    onChange={(e) => setCalcChurnRate(Number(e.target.value))}
                    className="calc-range-input"
                  />
                  <small className="help-sub">درصد اعضایی که در هر ماه تمدید نمی‌کنند.</small>
                </div>

                <div className="econ-slider-group">
                  <div className="slider-label-row">
                    <span>هزینه جذب هر مشتری (CAC):</span>
                    <strong>{formatCurrency(calcCac)}</strong>
                  </div>
                  <input
                    type="range"
                    min="100000"
                    max="1500000"
                    step="50000"
                    value={calcCac}
                    onChange={(e) => setCalcCac(Number(e.target.value))}
                    className="calc-range-input"
                  />
                </div>
              </div>

              {/* Output & Formulas Column */}
              <div className="economics-results-card">
                <h3>خروجی تحلیلی و شاخص‌های کلیدی سلامت پلتفرم</h3>

                <div className="econ-metrics-grid">
                  <div className="econ-tile">
                    <span>متوسط درآمد ماهانه هر کاربر (ARPU)</span>
                    <strong className="text-primary">{formatCurrency(economics.arpu)}</strong>
                    <small>فرمول: درآمد اشتراک + سهم کارمزد کلاس‌ها</small>
                  </div>

                  <div className="econ-tile">
                    <span>طول عمر وفاداری کاربر (Customer Lifespan)</span>
                    <strong>{economics.averageLifespanMonths} ماه</strong>
                    <small>فرمول: 1 / Churn Rate</small>
                  </div>

                  <div className="econ-tile">
                    <span>ارزش طول عمر مشتری (LTV)</span>
                    <strong className="text-emerald-500">{formatCurrency(economics.ltv)}</strong>
                    <small>فرمول: ARPU × Lifespan</small>
                  </div>

                  <div className="econ-tile highlight">
                    <span>نسبت LTV به CAC (شاخص بقای کسب‌وکار)</span>
                    <strong className={economics.healthyRatio ? "text-emerald-500" : "text-amber-500"}>
                      {economics.ltvCacRatio}x
                    </strong>
                    <small>آستانه استاندارد: حداقل ۳.۰ برابر</small>
                  </div>
                </div>

                <div className="financial-totals-banner">
                  <div className="total-col">
                    <span>درآمد ناخالص ماهانه (MRR پیش‌بینی):</span>
                    <strong>{formatCurrency(economics.monthlyGrossRevenue)}</strong>
                  </div>
                  <div className="total-col">
                    <span>درآمد سالانه معادل (ARR Run-Rate):</span>
                    <strong>{formatCurrency(economics.annualRunRate)}</strong>
                  </div>
                  <div className="total-col">
                    <span>دوره بازگشت هزینه جذب (Payback):</span>
                    <strong>{economics.paybackPeriodMonths} ماه</strong>
                  </div>
                </div>

                <div className="methodology-note">
                  <CheckCircle2 size={16} className="text-emerald-500 shrink-0" />
                  <p>
                    <strong>نتیجه‌گیری دانشگاهی:</strong> نسبت LTV/CAC فعلی معادل {economics.ltvCacRatio} برابر هزینه جذب است که نشان‌دهنده حاشیه امنیت اقتصادی بالا و توانایی مقیاس‌پذیری پایدار فیت‌لند می‌باشد.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* =======================================================
            TAB 8: SECURITY & TRUST
        ======================================================= */}
        {activeTab === "security" && (
          <div className="case-tab-content">
            <div className="case-section-intro">
              <span className="case-eyebrow">بخش هشتم</span>
              <h2>امنیت، حریم خصوصی و معماری تفکیک دسترسی (RBAC)</h2>
              <p>
                شفافیت ساختاری، حفاظت از حریم شخصی تصاویر و سنجه‌های بدنی، و مستندسازی صریح محدودیت‌های محیط لوکال/دمو.
              </p>
            </div>

            <div className="case-cards-grid">
              <div className="case-card">
                <h3>مدیریت دسترسی مبتنی بر نقش (Role-Based Access Control)</h3>
                <ul className="bullet-list">
                  <li><strong>عضو (Member):</strong> دسترسی منحصراً به برنامه‌ها، پرداخت‌ها، کلاس‌های رزروشده و رکوردهای اندازه‌گیری شخصی خود؛ عدم دسترسی به داده‌های سایر اعضا.</li>
                  <li><strong>مربی (Trainer):</strong> دسترسی به شاگردان اختصاص‌یافته، ویرایش برنامه تمرینی/تغذیه آنان و تقویم سانس‌ها؛ عدم دسترسی به گزارش‌های مالی کل یا اعضای سایر مربیان.</li>
                  <li><strong>مدیر کل (Admin):</strong> دسترسی به فهرست کلیه کاربران، تغییر نقش‌ها، مدیریت موجودی فروشگاه و گزارش درآمد تجمیعی.</li>
                </ul>
              </div>

              <div className="case-card">
                <h3>شفافیت محیط آزمایشی (Demo Disclosure)</h3>
                <div className="disclosure-box">
                  <AlertTriangle size={20} className="text-amber-500 shrink-0" />
                  <div>
                    <strong>بیانیه صریح ارزیابی دانشگاهی:</strong>
                    <p>
                      احراز هویت و نگهداری سشن‌های فعلی جهت سهولت ارائه بر بستر LocalStorage پیاده‌سازی شده است. در نسخه عملیاتی تجاری (Production)، این لایه با احراز هویت مبتنی بر توکن‌های امن JWT و کوکی‌های HttpOnly در بستر سرور بک‌اند ایمن جایگزین خواهد شد. کلیه پرداخت‌ها آزمایشی بوده و هیچ تراکنش بانکی واقعی انجام نمی‌شود.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* =======================================================
            TAB 9: STRATEGIC ROADMAP
        ======================================================= */}
        {activeTab === "roadmap" && (
          <div className="case-tab-content">
            <div className="case-section-intro">
              <span className="case-eyebrow">بخش نهم</span>
              <h2>نقشه راه استراتژیک محصول (Product Strategic Roadmap)</h2>
              <p>
                برنامه فازبندی‌شده از فاز آزمایشی دانشگاهی (MVP) تا تجاری‌سازی سراسری و یکپارچه‌سازی سخت‌افزارهای سلامت.
              </p>
            </div>

            <div className="roadmap-timeline">
              {[
                {
                  phase: "فاز ۱: نسخه اولیه (MVP) — وضعیت کنونی",
                  status: "تکمیل شده ✓",
                  statusClass: "completed",
                  items: [
                    "پیاده‌سازی هسته سه‌نقشه (عضو، مربی، مدیر)",
                    "سیستم رزرو آنلاین با موتور پیشگیری از تداخل زمانی",
                    "ماشین‌حساب هوشمند BMI و محاسبه‌گر اقتصاد پلتفرم",
                    "پشتیبانی کامل دوزبانه (فارسی RTL / انگلیسی LTR) و دو تم تاریک و روشن",
                    "سیستم پرداخت اقساطی آزمایشی با جدول سررسید",
                  ],
                },
                {
                  phase: "فاز ۲: اعتبارسنجی میدانی و پایلوت باشگاهی (Q1 2027)",
                  status: "در حال اقدام",
                  statusClass: "in-progress",
                  items: [
                    "استقرار نسخه پایلوت در ۳ باشگاه منتخب شهر یزد",
                    "اتصال به درگاه بانکی شاپرک و درگاه اقساطی اسنپ‌پی / دیجی‌پی",
                    "پیاده‌سازی چت مستقیم درون‌برنامه‌ای بین مربی و شاگرد با WebSocket",
                    "تست کاربری میدانی با ۱۰۰ ورزشکار و ثبت بازخوردهای UX",
                  ],
                },
                {
                  phase: "فاز ۳: هوش مصنوعی و تحلیل خودکار تصویر (Q3 2027)",
                  status: "برنامه‌ریزی‌شده",
                  statusClass: "planned",
                  items: [
                    "تحلیل تصویر فرم حرکات با استفاده از مدل‌های بینایی ماشین برای اصلاح اسکات و ددلیفت",
                    "پیشنهاد هوشمند جایگزینی مواد غذایی متناسب با کالری باقی‌مانده روز",
                    "اتصال به ساعت‌های هوشمند (Apple Health / Google Fit) جهت استخراج خودکار ضربان و کالری",
                  ],
                },
                {
                  phase: "فاز ۴: مقیاس‌پذیری کشوری و B2B باشگاه‌ها (2028)",
                  status: "چشم‌انداز بلندمدت",
                  statusClass: "future",
                  items: [
                    "سامانه مدیریت جامع منابع باشگاه (Gym ERP) شامل گیت ورود و کنترل تردد با QR",
                    "مارکت‌پلیس سراسری مربیان آنلاین با رتبه‌بندی کشوری",
                    "فرانچایزینگ نرم‌افزاری برای برندهای زنجیره‌ای تناسب اندام",
                  ],
                },
              ].map((phase, i) => (
                <div className={`roadmap-card ${phase.statusClass}`} key={i}>
                  <div className="roadmap-head">
                    <span className="phase-title">{phase.phase}</span>
                    <span className={`phase-badge ${phase.statusClass}`}>{phase.status}</span>
                  </div>
                  <ul className="phase-items">
                    {phase.items.map((item, idx) => (
                      <li key={idx}>
                        <CheckCircle2 size={15} className="shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Interactive Scenario Runner Modal */}
      <ScenarioRunnerModal
        isOpen={isScenarioModalOpen}
        onClose={() => setIsScenarioModalOpen(false)}
      />
    </div>
  );
}
